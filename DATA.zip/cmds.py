print("""
    CMDS
    _________________
    LOG - Start log-in prosses
    S_IN - Sign in
    S_OUT - Sign out 
    S_NEW - New user acc.

    """)
import data.py