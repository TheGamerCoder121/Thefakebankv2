print("""
    CMD - list fo commands
    EXIT - Exit program
    Help - starter cmds
""")
import data.py