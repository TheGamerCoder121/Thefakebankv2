import time
import warnings

print("Hello")
warnings.warn("This program is still being make and is not purfect")
warnings.warn("Repl.it may crash here and there, so don't be mad")
time.sleep(3)
import data.py